<?php
require_once 'header.php';

// Mock data for monitoring
$recent_messages = $conn->query("SELECT m.*, u1.username as sender, u2.username as receiver FROM messages m JOIN users u1 ON m.sender_id = u1.id JOIN users u2 ON m.receiver_id = u2.id ORDER BY m.created_at DESC LIMIT 10");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Monitoring Aktivitas</h2>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body">
                <h5 class="fw-bold mb-3">Interaksi Terkini (Pesan)</h5>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Waktu</th>
                                <th>Pengirim</th>
                                <th>Penerima</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($recent_messages && $recent_messages->num_rows > 0): ?>
                                <?php while($msg = $recent_messages->fetch_assoc()): ?>
                                    <tr>
                                        <td><small><?php echo date('d/m H:i', strtotime($msg['created_at'])); ?></small></td>
                                        <td>@<?php echo htmlspecialchars($msg['sender']); ?></td>
                                        <td>@<?php echo htmlspecialchars($msg['receiver']); ?></td>
                                        <td><?php echo $msg['is_read'] ? '<span class="badge bg-success">Dibaca</span>' : '<span class="badge bg-secondary">Terkirim</span>'; ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" class="text-center">Belum ada interaksi chat.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 bg-danger text-white mb-4">
            <div class="card-body">
                <h5 class="fw-bold mb-3"><i class="fa-solid fa-flag me-2"></i>Laporan Penyalahgunaan</h5>
                <p>Belum ada laporan dari pengguna.</p>
                <button class="btn btn-light btn-sm mt-2">Lihat Detail Laporan</button>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
