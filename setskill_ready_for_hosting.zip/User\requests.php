<?php
require_once 'header.php';

// Handle Action Send
if (isset($_GET['action']) && $_GET['action'] == 'send' && isset($_GET['to'])) {
    $to = (int)$_GET['to'];
    if ($to != $user_id) {
        // Check if request already exists
        $check = $conn->query("SELECT id FROM requests WHERE sender_id=$user_id AND receiver_id=$to AND status='pending'");
        if ($check->num_rows == 0) {
            $conn->query("INSERT INTO requests (sender_id, receiver_id, status) VALUES ($user_id, $to, 'pending')");
            $success = "Permintaan berhasil dikirim.";
        }
    }
}

// Handle Action Accept/Reject
if (isset($_GET['update']) && isset($_GET['id'])) {
    $req_id = (int)$_GET['id'];
    $status = $_GET['update'];
    if (in_array($status, ['accepted', 'rejected'])) {
        $conn->query("UPDATE requests SET status='$status' WHERE id=$req_id AND receiver_id=$user_id");
    }
    header("Location: requests.php");
    exit();
}

// Fetch Incoming
$incoming = $conn->query("SELECT r.*, u.name, u.username FROM requests r JOIN users u ON r.sender_id = u.id WHERE r.receiver_id = $user_id ORDER BY r.created_at DESC");

// Fetch Outgoing
$outgoing = $conn->query("SELECT r.*, u.name, u.username FROM requests r JOIN users u ON r.receiver_id = u.id WHERE r.sender_id = $user_id ORDER BY r.created_at DESC");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Request Belajar</h2>
</div>

<?php if (isset($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

<div class="row">
    <!-- Incoming Requests -->
    <div class="col-md-6 mb-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-bottom pt-4 pb-3">
                <h5 class="fw-bold mb-0"><i class="fa-solid fa-inbox me-2 text-primary"></i>Masuk (Incoming)</h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if ($incoming->num_rows > 0): ?>
                        <?php while($req = $incoming->fetch_assoc()): ?>
                            <div class="list-group-item py-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="fw-bold mb-1"><?php echo htmlspecialchars($req['name']); ?></h6>
                                        <small class="text-muted">Mengajukan permintaan pada <?php echo date('d M, H:i', strtotime($req['created_at'])); ?></small>
                                    </div>
                                    <div>
                                        <?php if($req['status'] == 'pending'): ?>
                                            <a href="requests.php?update=accepted&id=<?php echo $req['id']; ?>" class="btn btn-sm btn-success me-1"><i class="fa-solid fa-check"></i> Terima</a>
                                            <a href="requests.php?update=rejected&id=<?php echo $req['id']; ?>" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-times"></i> Tolak</a>
                                        <?php elseif($req['status'] == 'accepted'): ?>
                                            <span class="badge bg-success">Diterima</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Ditolak</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">Tidak ada request masuk.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Outgoing Requests -->
    <div class="col-md-6 mb-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-header bg-white border-bottom pt-4 pb-3">
                <h5 class="fw-bold mb-0"><i class="fa-solid fa-paper-plane me-2 text-primary"></i>Keluar (Outgoing)</h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if ($outgoing->num_rows > 0): ?>
                        <?php while($req = $outgoing->fetch_assoc()): ?>
                            <div class="list-group-item py-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h6 class="fw-bold mb-1">Ke: <?php echo htmlspecialchars($req['name']); ?></h6>
                                        <small class="text-muted">Dikirim pada <?php echo date('d M, H:i', strtotime($req['created_at'])); ?></small>
                                    </div>
                                    <div>
                                        <?php if($req['status'] == 'pending'): ?>
                                            <span class="badge bg-warning text-dark">Menunggu</span>
                                        <?php elseif($req['status'] == 'accepted'): ?>
                                            <span class="badge bg-success">Diterima</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Ditolak</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">Anda belum mengirim request apapun.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
