<?php
require_once 'header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Jadwal Belajar</h2>
    <button class="btn btn-primary rounded-pill"><i class="fa-solid fa-plus me-2"></i>Tambah Jadwal</button>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Jadwal Minggu Ini</h5>
                
                <div class="list-group list-group-flush">
                    <div class="list-group-item px-0 py-3 border-bottom">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="bg-light-blue text-primary rounded-3 text-center p-2 me-3" style="min-width: 60px;">
                                    <h5 class="fw-bold mb-0">12</h5>
                                    <small>Okt</small>
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-1">Belajar PHP Dasar</h6>
                                    <small class="text-muted"><i class="fa-solid fa-clock me-1"></i> 14:00 - 16:00 | <i class="fa-solid fa-user me-1"></i> Dengan Budi</small>
                                </div>
                            </div>
                            <span class="badge bg-success rounded-pill">Akan Datang</span>
                        </div>
                    </div>
                    
                    <div class="list-group-item px-0 py-3 border-bottom">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center">
                                <div class="bg-light-blue text-primary rounded-3 text-center p-2 me-3" style="min-width: 60px;">
                                    <h5 class="fw-bold mb-0">15</h5>
                                    <small>Okt</small>
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-1">Sesi Desain Grafis (Mengajar)</h6>
                                    <small class="text-muted"><i class="fa-solid fa-clock me-1"></i> 10:00 - 12:00 | <i class="fa-solid fa-video me-1"></i> Online (Google Meet)</small>
                                </div>
                            </div>
                            <span class="badge bg-warning text-dark rounded-pill">Menunggu Konfirmasi</span>
                        </div>
                    </div>
                </div>
                
                <div class="text-center mt-4">
                    <p class="text-muted small">Catatan: Fitur jadwal saat ini adalah preview statis. Anda dapat mengatur jadwal sebenarnya melalui chat dengan partner.</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4 text-center">
                <i class="fa-regular fa-calendar-check fa-3x text-primary mb-3"></i>
                <h5 class="fw-bold">Sinkronisasi Kalender</h5>
                <p class="text-muted small mb-3">Hubungkan dengan Google Calendar Anda untuk pengingat otomatis.</p>
                <button class="btn btn-outline-primary btn-sm rounded-pill w-100">Hubungkan <i class="fa-brands fa-google ms-1"></i></button>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
