<?php
require_once 'header.php';

// Get total users
$stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'user'");
$total_users = $stmt->fetch_assoc()['total'];

// Get active users (for now, active status)
$stmt = $conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'user' AND status = 'active'");
$active_users = $stmt->fetch_assoc()['total'];

// Get total skills offered
$stmt = $conn->query("SELECT COUNT(*) as total FROM user_skills WHERE type_skill = 'have'");
$total_skills = $stmt->fetch_assoc()['total'];

// Get top skills
$stmt = $conn->query("SELECT s.name, COUNT(us.id) as count FROM skills s JOIN user_skills us ON s.id = us.skill_id GROUP BY s.id ORDER BY count DESC LIMIT 5");
$top_skills = [];
while ($row = $stmt->fetch_assoc()) {
    $top_skills[] = $row;
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Dashboard Statistik</h2>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card card-stat">
            <div class="card-body d-flex align-items-center">
                <div class="icon-box bg-light-blue me-3">
                    <i class="fa-solid fa-users"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Total Users</h6>
                    <h3 class="fw-bold mb-0"><?php echo $total_users; ?></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-stat">
            <div class="card-body d-flex align-items-center">
                <div class="icon-box bg-light-green me-3">
                    <i class="fa-solid fa-user-check"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Active Users</h6>
                    <h3 class="fw-bold mb-0"><?php echo $active_users; ?></h3>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card card-stat">
            <div class="card-body d-flex align-items-center">
                <div class="icon-box bg-light-yellow me-3">
                    <i class="fa-solid fa-lightbulb"></i>
                </div>
                <div>
                    <h6 class="text-muted mb-1">Skills Offered</h6>
                    <h3 class="fw-bold mb-0"><?php echo $total_skills; ?></h3>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6 mb-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body">
                <h5 class="fw-bold mb-3">Skill Paling Populer</h5>
                <ul class="list-group list-group-flush">
                    <?php if (empty($top_skills)): ?>
                        <li class="list-group-item text-muted">Belum ada data skill.</li>
                    <?php else: ?>
                        <?php foreach($top_skills as $skill): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo htmlspecialchars($skill['name']); ?>
                                <span class="badge bg-primary rounded-pill"><?php echo $skill['count']; ?></span>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="col-lg-6 mb-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-body">
                <h5 class="fw-bold mb-3">Notifikasi Sistem</h5>
                <div class="alert alert-info">
                    <i class="fa-solid fa-info-circle me-2"></i> Sistem berjalan normal. Tidak ada aktivitas mencurigakan yang terdeteksi.
                </div>
                <div class="alert alert-warning">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i> Terdapat 0 pengguna dengan rating rendah bulan ini.
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
