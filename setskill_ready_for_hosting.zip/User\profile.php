<?php
require_once 'header.php';

$success = '';
$error = '';

// Update Profile
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $location = trim($_POST['location']);
    $bio = trim($_POST['bio']);
    $gender = isset($_POST['gender']) ? trim($_POST['gender']) : null;
    
    // Handle file upload
    $profile_picture = $current_user['profile_picture'] ?? null;
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['profile_picture']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $new_filename = uniqid('profile_') . '.' . $ext;
            $upload_path = '../assets/uploads/profiles/' . $new_filename;
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                $profile_picture = $new_filename;
            }
        } else {
            $error = "Format file foto tidak diizinkan. Gunakan JPG, PNG, atau GIF.";
        }
    }
    
    if (empty($error)) {
        $stmt = $conn->prepare("UPDATE users SET name=?, phone=?, location=?, bio=?, gender=?, profile_picture=? WHERE id=?");
        $stmt->bind_param("ssssssi", $name, $phone, $location, $bio, $gender, $profile_picture, $user_id);
        if ($stmt->execute()) {
            $success = "Profil berhasil diperbarui.";
            // Refresh data
            $current_user['name'] = $name;
            $current_user['phone'] = $phone;
            $current_user['location'] = $location;
            $current_user['bio'] = $bio;
            $current_user['gender'] = $gender;
            $current_user['profile_picture'] = $profile_picture;
        } else {
            $error = "Gagal memperbarui profil.";
        }
        $stmt->close();
    }
}

// Add Skill
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_skill'])) {
    $skill_id = (int)$_POST['skill_id'];
    $type_skill = $_POST['type_skill'];
    
    // Check if already exist
    $check = $conn->query("SELECT id FROM user_skills WHERE user_id=$user_id AND skill_id=$skill_id AND type_skill='$type_skill'");
    if ($check->num_rows == 0) {
        $stmt = $conn->prepare("INSERT INTO user_skills (user_id, skill_id, type_skill) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $user_id, $skill_id, $type_skill);
        $stmt->execute();
        $stmt->close();
        $success = "Skill berhasil ditambahkan.";
    } else {
        $error = "Skill tersebut sudah ada di daftar Anda.";
    }
}

// Remove Skill
if (isset($_GET['remove_skill'])) {
    $id = (int)$_GET['remove_skill'];
    $conn->query("DELETE FROM user_skills WHERE id=$id AND user_id=$user_id");
    header("Location: profile.php");
    exit();
}

// Fetch available skills
$all_skills = $conn->query("SELECT * FROM skills ORDER BY name");

// Fetch user's skills
$my_skills = $conn->query("SELECT us.id, s.name, us.type_skill FROM user_skills us JOIN skills s ON us.skill_id = s.id WHERE us.user_id = $user_id");
$have_skills = [];
$want_skills = [];
while($row = $my_skills->fetch_assoc()) {
    if ($row['type_skill'] == 'have') $have_skills[] = $row;
    else $want_skills[] = $row;
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Profil & Skill</h2>
</div>

<?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>

<div class="row">
    <!-- Profile Form -->
    <div class="col-lg-5 mb-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Informasi Dasar</h5>
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-4 text-center">
                        <div class="position-relative d-inline-block mb-2">
                            <?php if(!empty($current_user['profile_picture'])): ?>
                                <img src="../assets/uploads/profiles/<?php echo htmlspecialchars($current_user['profile_picture']); ?>" class="rounded-circle border border-3 border-white shadow-sm" style="width: 120px; height: 120px; object-fit: cover;" alt="Profile Picture">
                            <?php else: ?>
                                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto border border-3 border-white shadow-sm" style="width: 120px; height: 120px; font-size: 3rem;">
                                    <?php echo strtoupper(substr($current_user['name'], 0, 1)); ?>
                                </div>
                            <?php endif; ?>
                            <label for="profileUpload" class="position-absolute bottom-0 end-0 bg-white rounded-circle p-2 shadow-sm border" style="cursor: pointer;">
                                <i class="fa-solid fa-camera text-primary"></i>
                            </label>
                        </div>
                        <input type="file" id="profileUpload" name="profile_picture" class="d-none" accept="image/*">
                        <div class="small text-muted mt-1">Format: JPG, PNG, GIF</div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Nama Lengkap</label>
                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($current_user['name']); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Username / Email</label>
                        <input type="text" class="form-control bg-light" value="@<?php echo htmlspecialchars($current_user['username']); ?> / <?php echo htmlspecialchars($current_user['email']); ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Nomor Telepon</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($current_user['phone'] ?? ''); ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Jenis Kelamin</label>
                        <select name="gender" class="form-select">
                            <option value="">-- Pilih Jenis Kelamin --</option>
                            <option value="Laki-laki" <?php echo (isset($current_user['gender']) && $current_user['gender'] == 'Laki-laki') ? 'selected' : ''; ?>>Laki-laki</option>
                            <option value="Perempuan" <?php echo (isset($current_user['gender']) && $current_user['gender'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
                            <option value="Lainnya" <?php echo (isset($current_user['gender']) && $current_user['gender'] == 'Lainnya') ? 'selected' : ''; ?>>Lainnya</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label text-muted small fw-bold">Lokasi (Kota/Daerah)</label>
                        <input type="text" name="location" class="form-control" value="<?php echo htmlspecialchars($current_user['location'] ?? ''); ?>" placeholder="Contoh: Jakarta Selatan">
                    </div>
                    <div class="mb-4">
                        <label class="form-label text-muted small fw-bold">Bio Pendek</label>
                        <textarea name="bio" class="form-control" rows="3" placeholder="Ceritakan sedikit tentang Anda..."><?php echo htmlspecialchars($current_user['bio'] ?? ''); ?></textarea>
                    </div>
                    <button type="submit" name="update_profile" class="btn btn-primary w-100 rounded-pill">Simpan Profil</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Skills Management -->
    <div class="col-lg-7 mb-4">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Manajemen Skill</h5>
                
                <form method="POST" class="row g-2 align-items-end mb-4">
                    <div class="col-md-5">
                        <label class="form-label text-muted small fw-bold">Pilih Skill</label>
                        <select name="skill_id" class="form-select" required>
                            <option value="">-- Pilih --</option>
                            <?php $all_skills->data_seek(0); while($s = $all_skills->fetch_assoc()): ?>
                                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label text-muted small fw-bold">Tipe</label>
                        <select name="type_skill" class="form-select" required>
                            <option value="have">Bisa Mengajarkan (Have)</option>
                            <option value="want">Ingin Mempelajari (Want)</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit" name="add_skill" class="btn btn-outline-primary w-100"><i class="fa-solid fa-plus me-1"></i> Tambah</button>
                    </div>
                </form>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <h6 class="fw-bold text-success mb-3"><i class="fa-solid fa-chalkboard-user me-2"></i>Skill Saya (Mengajar)</h6>
                        <ul class="list-group list-group-flush border rounded-3">
                            <?php if(empty($have_skills)): ?><li class="list-group-item text-muted small">Belum ada skill.</li><?php endif; ?>
                            <?php foreach($have_skills as $s): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <?php echo htmlspecialchars($s['name']); ?>
                                    <a href="profile.php?remove_skill=<?php echo $s['id']; ?>" class="text-danger"><i class="fa-solid fa-times"></i></a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="col-md-6 mb-3">
                        <h6 class="fw-bold text-primary mb-3"><i class="fa-solid fa-book-open-reader me-2"></i>Ingin Dipelajari (Belajar)</h6>
                        <ul class="list-group list-group-flush border rounded-3">
                            <?php if(empty($want_skills)): ?><li class="list-group-item text-muted small">Belum ada skill.</li><?php endif; ?>
                            <?php foreach($want_skills as $s): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <?php echo htmlspecialchars($s['name']); ?>
                                    <a href="profile.php?remove_skill=<?php echo $s['id']; ?>" class="text-danger"><i class="fa-solid fa-times"></i></a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
