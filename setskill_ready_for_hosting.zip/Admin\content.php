<?php
require_once 'header.php';

// Handle adding category
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    $name = trim($_POST['name']);
    $category = trim($_POST['category']);
    
    if (!empty($name) && !empty($category)) {
        $stmt = $conn->prepare("INSERT INTO skills (name, category) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $category);
        if ($stmt->execute()) {
            $success = "Skill/Kategori berhasil ditambahkan.";
        }
        $stmt->close();
    }
}

// Handle delete
if (isset($_GET['delete_skill'])) {
    $id = (int)$_GET['delete_skill'];
    $conn->query("DELETE FROM skills WHERE id = $id");
    header("Location: content.php");
    exit();
}

$skills = $conn->query("SELECT * FROM skills ORDER BY category, name");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Manajemen Konten & Kategori</h2>
</div>

<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-4 mb-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body">
                <h5 class="fw-bold mb-3">Tambah Kategori Skill</h5>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Nama Skill</label>
                        <input type="text" name="name" class="form-control" required placeholder="Contoh: Python">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kategori</label>
                        <input type="text" name="category" class="form-control" required placeholder="Contoh: Programming">
                    </div>
                    <button type="submit" name="add_category" class="btn btn-primary w-100">Tambah</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-lg-8 mb-4">
        <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="ps-4">Kategori</th>
                                <th>Nama Skill</th>
                                <th class="pe-4 text-end">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($skills->num_rows > 0): ?>
                                <?php while($skill = $skills->fetch_assoc()): ?>
                                    <tr>
                                        <td class="ps-4"><span class="badge bg-secondary"><?php echo htmlspecialchars($skill['category']); ?></span></td>
                                        <td><?php echo htmlspecialchars($skill['name']); ?></td>
                                        <td class="pe-4 text-end">
                                            <a href="content.php?delete_skill=<?php echo $skill['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus skill ini?');"><i class="fa-solid fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="3" class="text-center">Belum ada skill.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
