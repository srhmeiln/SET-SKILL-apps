<?php
require_once 'header.php';

// Check if chatting with someone
$to_id = isset($_GET['to']) ? (int)$_GET['to'] : 0;
$to_user = null;

if ($to_id > 0) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND role = 'user'");
    $stmt->bind_param("i", $to_id);
    $stmt->execute();
    $to_user = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if ($to_user) {
        // Mark messages as read
        $conn->query("UPDATE messages SET is_read = 1 WHERE sender_id = $to_id AND receiver_id = $user_id");
        
        // Handle send message
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_msg'])) {
            $msg = trim($_POST['message']);
            if (!empty($msg)) {
                $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
                $stmt->bind_param("iis", $user_id, $to_id, $msg);
                $stmt->execute();
                $stmt->close();
                header("Location: messages.php?to=$to_id");
                exit();
            }
        }
        
        // Fetch messages
        $messages = $conn->query("SELECT * FROM messages WHERE (sender_id = $user_id AND receiver_id = $to_id) OR (sender_id = $to_id AND receiver_id = $user_id) ORDER BY created_at ASC");
    }
}

// Fetch chat list (users who we have messaged or messaged us)
$chat_list = $conn->query("SELECT u.id, u.name, u.username, 
    (SELECT message FROM messages WHERE (sender_id = $user_id AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = $user_id) ORDER BY created_at DESC LIMIT 1) as last_msg,
    (SELECT COUNT(*) FROM messages WHERE sender_id = u.id AND receiver_id = $user_id AND is_read = 0) as unread
    FROM users u 
    WHERE u.id IN (SELECT sender_id FROM messages WHERE receiver_id = $user_id UNION SELECT receiver_id FROM messages WHERE sender_id = $user_id)
    AND u.id != $user_id");
?>

<div class="row h-100" style="min-height: 70vh;">
    <!-- Chat List -->
    <div class="col-md-4 mb-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-header bg-white border-0 pt-4 pb-0">
                <h5 class="fw-bold mb-3">Pesan</h5>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if ($chat_list && $chat_list->num_rows > 0): ?>
                        <?php while($c = $chat_list->fetch_assoc()): ?>
                            <a href="messages.php?to=<?php echo $c['id']; ?>" class="list-group-item list-group-item-action border-0 py-3 <?php echo ($to_id == $c['id']) ? 'bg-light' : ''; ?>">
                                <div class="d-flex align-items-center">
                                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 45px; height: 45px;">
                                        <?php echo strtoupper(substr($c['name'], 0, 1)); ?>
                                    </div>
                                    <div class="flex-grow-1 min-width-0">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <h6 class="mb-0 fw-bold text-truncate"><?php echo htmlspecialchars($c['name']); ?></h6>
                                            <?php if($c['unread'] > 0): ?>
                                                <span class="badge bg-danger rounded-pill"><?php echo $c['unread']; ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <p class="mb-0 text-muted small text-truncate"><?php echo htmlspecialchars($c['last_msg']); ?></p>
                                    </div>
                                </div>
                            </a>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center p-4 text-muted">Belum ada percakapan.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Chat Box -->
    <div class="col-md-8 mb-4">
        <div class="card border-0 shadow-sm rounded-4 h-100 d-flex flex-column">
            <?php if ($to_user): ?>
                <div class="card-header bg-white border-bottom py-3 d-flex align-items-center">
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                        <?php echo strtoupper(substr($to_user['name'], 0, 1)); ?>
                    </div>
                    <div>
                        <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($to_user['name']); ?></h6>
                        <small class="text-muted">@<?php echo htmlspecialchars($to_user['username']); ?></small>
                    </div>
                </div>
                
                <div class="card-body overflow-auto" style="max-height: 500px;" id="chatBox">
                    <?php if ($messages->num_rows > 0): ?>
                        <?php while($m = $messages->fetch_assoc()): ?>
                            <?php if ($m['sender_id'] == $user_id): ?>
                                <!-- My message -->
                                <div class="d-flex justify-content-end mb-3">
                                    <div class="bg-primary text-white p-3 rounded-4 rounded-bottom-0 shadow-sm" style="max-width: 75%;">
                                        <?php echo nl2br(htmlspecialchars($m['message'])); ?>
                                        <div class="small mt-1 text-white-50 text-end" style="font-size: 0.7rem;"><?php echo date('H:i', strtotime($m['created_at'])); ?></div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <!-- Their message -->
                                <div class="d-flex justify-content-start mb-3">
                                    <div class="bg-light p-3 rounded-4 rounded-bottom-0 shadow-sm border" style="max-width: 75%;">
                                        <?php echo nl2br(htmlspecialchars($m['message'])); ?>
                                        <div class="small mt-1 text-muted text-end" style="font-size: 0.7rem;"><?php echo date('H:i', strtotime($m['created_at'])); ?></div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center text-muted py-5">Kirim pesan pertama untuk memulai percakapan.</div>
                    <?php endif; ?>
                </div>
                
                <div class="card-footer bg-white border-top p-3">
                    <form method="POST" class="d-flex">
                        <input type="text" name="message" class="form-control rounded-pill me-2" placeholder="Tulis pesan..." required autocomplete="off">
                        <button type="submit" name="send_msg" class="btn btn-primary rounded-circle" style="width: 45px; height: 45px;"><i class="fa-solid fa-paper-plane"></i></button>
                    </form>
                </div>
                <script>
                    // Scroll to bottom
                    var chatBox = document.getElementById("chatBox");
                    chatBox.scrollTop = chatBox.scrollHeight;
                </script>
            <?php else: ?>
                <div class="card-body d-flex flex-column justify-content-center align-items-center text-muted">
                    <i class="fa-regular fa-comments fa-4x mb-3 text-light"></i>
                    <h5>Pilih percakapan untuk mulai chat</h5>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
