<?php
require_once 'header.php';

// Fetch users we have accepted requests with
$interacted_users = $conn->query("
    SELECT u.id, u.name, u.username 
    FROM users u 
    JOIN requests r ON (r.sender_id = $user_id AND r.receiver_id = u.id AND r.status = 'accepted') 
       OR (r.receiver_id = $user_id AND r.sender_id = u.id AND r.status = 'accepted')
    WHERE u.id != $user_id
    GROUP BY u.id
");

// Handle Submit Rating
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_rating'])) {
    $ratee_id = (int)$_POST['ratee_id'];
    $rating = (int)$_POST['rating'];
    $review = trim($_POST['review']);
    
    if ($rating >= 1 && $rating <= 5) {
        $stmt = $conn->prepare("INSERT INTO ratings (rater_id, ratee_id, rating, review) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiis", $user_id, $ratee_id, $rating, $review);
        if ($stmt->execute()) {
            $success = "Rating berhasil dikirim. Terima kasih!";
        }
        $stmt->close();
    }
}

// Fetch received ratings
$my_ratings = $conn->query("SELECT r.*, u.name FROM ratings r JOIN users u ON r.rater_id = u.id WHERE r.ratee_id = $user_id ORDER BY r.created_at DESC");

// Calculate average
$avg_res = $conn->query("SELECT AVG(rating) as avg_rating, COUNT(id) as total_reviews FROM ratings WHERE ratee_id = $user_id");
$avg_data = $avg_res->fetch_assoc();
$avg_rating = round($avg_data['avg_rating'], 1) ?? 0;
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Rating & Ulasan</h2>
</div>

<?php if (isset($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

<div class="row">
    <!-- Submit Rating -->
    <div class="col-md-5 mb-4">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Berikan Rating</h5>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Pilih Partner</label>
                        <select name="ratee_id" class="form-select" required>
                            <option value="">-- Pilih Partner Belajar --</option>
                            <?php if($interacted_users): while($u = $interacted_users->fetch_assoc()): ?>
                                <option value="<?php echo $u['id']; ?>"><?php echo htmlspecialchars($u['name']); ?> (@<?php echo htmlspecialchars($u['username']); ?>)</option>
                            <?php endwhile; endif; ?>
                        </select>
                        <div class="form-text">Hanya user dengan request diterima yang muncul disini.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Rating (1-5)</label>
                        <div class="d-flex align-items-center gap-3">
                            <input type="radio" name="rating" value="1" required> 1
                            <input type="radio" name="rating" value="2"> 2
                            <input type="radio" name="rating" value="3"> 3
                            <input type="radio" name="rating" value="4"> 4
                            <input type="radio" name="rating" value="5" checked> 5 <i class="fa-solid fa-star text-warning"></i>
                        </div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Ulasan (Opsional)</label>
                        <textarea name="review" class="form-control" rows="3" placeholder="Tulis pengalaman belajar Anda dengan partner ini..."></textarea>
                    </div>
                    <button type="submit" name="submit_rating" class="btn btn-primary w-100 rounded-pill">Kirim Rating</button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- Received Ratings -->
    <div class="col-md-7 mb-4">
        <div class="card border-0 shadow-sm rounded-4 h-100">
            <div class="card-header bg-white border-bottom p-4">
                <div class="d-flex align-items-center justify-content-between">
                    <h5 class="fw-bold mb-0">Ulasan Diterima</h5>
                    <div class="text-end">
                        <h3 class="fw-bold text-warning mb-0"><i class="fa-solid fa-star"></i> <?php echo $avg_rating; ?></h3>
                        <small class="text-muted">Dari <?php echo $avg_data['total_reviews']; ?> ulasan</small>
                    </div>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="list-group list-group-flush">
                    <?php if ($my_ratings->num_rows > 0): ?>
                        <?php while($r = $my_ratings->fetch_assoc()): ?>
                            <div class="list-group-item p-4">
                                <div class="d-flex justify-content-between mb-2">
                                    <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($r['name']); ?></h6>
                                    <div class="text-warning small">
                                        <?php for($i=0; $i<$r['rating']; $i++) echo '<i class="fa-solid fa-star"></i>'; ?>
                                        <?php for($i=$r['rating']; $i<5; $i++) echo '<i class="fa-regular fa-star"></i>'; ?>
                                    </div>
                                </div>
                                <p class="text-muted mb-1"><?php echo htmlspecialchars($r['review']); ?></p>
                                <small class="text-muted" style="font-size: 0.7rem;"><?php echo date('d M Y', strtotime($r['created_at'])); ?></small>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="text-center py-5 text-muted">Belum ada ulasan diterima.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
