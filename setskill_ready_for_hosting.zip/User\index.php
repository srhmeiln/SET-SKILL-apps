<?php
require_once 'header.php';

// Rekomendasi sederhana: User yang mencari skill yang kita miliki, atau memiliki skill yang kita cari
// Ambil skill yang kita cari
$want_stmt = $conn->prepare("SELECT skill_id FROM user_skills WHERE user_id = ? AND type_skill = 'want'");
$want_stmt->bind_param("i", $user_id);
$want_stmt->execute();
$want_result = $want_stmt->get_result();
$wanted_skills = [];
while($row = $want_result->fetch_assoc()) $wanted_skills[] = $row['skill_id'];
$want_stmt->close();

// Ambil pengguna di sekitar secara acak (simulasi)
$nearby_sql = "SELECT id, name, location, bio FROM users WHERE id != ? AND status = 'active' ORDER BY RAND() LIMIT 4";
$nearby_stmt = $conn->prepare($nearby_sql);
$nearby_stmt->bind_param("i", $user_id);
$nearby_stmt->execute();
$nearby_res = $nearby_stmt->get_result();
$nearby_users = [];
while($row = $nearby_res->fetch_assoc()) $nearby_users[] = $row;
$nearby_stmt->close();

$recommendations = [];
if (!empty($wanted_skills)) {
    $placeholders = implode(',', array_fill(0, count($wanted_skills), '?'));
    $types = str_repeat('i', count($wanted_skills));
    
    // Cari user yang 'have' skill yang kita 'want'
    $rec_sql = "SELECT DISTINCT u.id, u.name, u.username, u.location, u.bio 
                FROM users u 
                JOIN user_skills us ON u.id = us.user_id 
                WHERE us.type_skill = 'have' 
                AND us.skill_id IN ($placeholders) 
                AND u.id != ? AND u.status = 'active'";
    
    $rec_stmt = $conn->prepare($rec_sql);
    
    $bind_params = $wanted_skills;
    $bind_params[] = $user_id;
    $types .= 'i';
    
    $rec_stmt->bind_param($types, ...$bind_params);
    $rec_stmt->execute();
    $rec_res = $rec_stmt->get_result();
    while($row = $rec_res->fetch_assoc()) {
        // Get their skills
        $s_stmt = $conn->prepare("SELECT s.name FROM skills s JOIN user_skills us ON s.id = us.skill_id WHERE us.user_id = ? AND us.type_skill = 'have'");
        $s_stmt->bind_param("i", $row['id']);
        $s_stmt->execute();
        $s_res = $s_stmt->get_result();
        $skills = [];
        while($s = $s_res->fetch_assoc()) $skills[] = $s['name'];
        $row['skills'] = $skills;
        
        $recommendations[] = $row;
    }
}
?>

<div class="mb-4">
    <h2 class="fw-bold">Selamat datang, <?php echo htmlspecialchars($current_user['name']); ?>! 👋</h2>
    <p class="text-muted">Temukan partner belajar yang sesuai dengan kebutuhan Anda hari ini.</p>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold mb-0">Rekomendasi Partner Untuk Anda</h5>
            <a href="#" class="text-decoration-none small">Lihat Semua</a>
        </div>
        
        <?php if (empty($recommendations)): ?>
            <div class="card border-0 shadow-sm rounded-4 mb-4">
                <div class="card-body text-center py-5">
                    <img src="https://cdn-icons-png.flaticon.com/512/7486/7486744.png" alt="Empty" width="100" class="mb-3 opacity-50">
                    <h5 class="fw-bold text-muted">Belum ada rekomendasi</h5>
                    <p class="text-muted mb-3">Tambahkan skill yang ingin Anda pelajari di menu Profil untuk mendapatkan rekomendasi partner.</p>
                    <a href="profile.php" class="btn btn-primary rounded-pill px-4">Update Profil</a>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-3 mb-4">
                <?php foreach($recommendations as $rec): ?>
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm rounded-4 h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center mb-3">
                                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 50px; height: 50px; font-size: 1.2rem;">
                                    <?php echo strtoupper(substr($rec['name'], 0, 1)); ?>
                                </div>
                                <div>
                                    <h6 class="fw-bold mb-0"><?php echo htmlspecialchars($rec['name']); ?></h6>
                                    <small class="text-muted"><i class="fa-solid fa-location-dot me-1"></i> <?php echo htmlspecialchars($rec['location'] ?? 'Lokasi tidak diatur'); ?></small>
                                </div>
                            </div>
                            <p class="small text-muted mb-2 line-clamp-2"><?php echo htmlspecialchars($rec['bio'] ?? 'Tidak ada bio.'); ?></p>
                            <div class="mb-3">
                                <?php foreach(array_slice($rec['skills'], 0, 2) as $s): ?>
                                    <span class="badge bg-light text-dark border border-secondary-subtle"><?php echo htmlspecialchars($s); ?></span>
                                <?php endforeach; ?>
                                <?php if(count($rec['skills']) > 2): ?>
                                    <span class="badge bg-light text-dark border border-secondary-subtle">+<?php echo count($rec['skills']) - 2; ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="d-grid gap-2">
                                <a href="requests.php?action=send&to=<?php echo $rec['id']; ?>" class="btn btn-primary btn-sm rounded-pill">Ajukan Request</a>
                                <a href="messages.php?to=<?php echo $rec['id']; ?>" class="btn btn-outline-secondary btn-sm rounded-pill">Kirim Pesan</a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="col-lg-4">
        <!-- Tampilan Profil -->
        <h5 class="fw-bold mb-3">Profil Anda</h5>
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body text-center py-4">
                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3 <?php echo !empty($current_user['profile_picture']) ? 'd-none' : ''; ?>" style="width: 80px; height: 80px; font-size: 2.5rem;">
                    <?php echo strtoupper(substr($current_user['name'], 0, 1)); ?>
                </div>
                <?php if(!empty($current_user['profile_picture'])): ?>
                    <img src="../assets/uploads/profiles/<?php echo htmlspecialchars($current_user['profile_picture']); ?>" class="rounded-circle mx-auto mb-3 border border-3 border-white shadow-sm" style="width: 80px; height: 80px; object-fit: cover;" alt="Profile Picture">
                <?php endif; ?>
                <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($current_user['name']); ?></h5>
                <p class="text-muted small mb-2"><i class="fa-solid fa-location-dot me-1"></i> <?php echo htmlspecialchars($current_user['location'] ?? 'Lokasi belum diatur'); ?></p>
                <p class="small text-muted px-3 mb-3"><?php echo htmlspecialchars($current_user['bio'] ?? 'Ceritakan sedikit tentang diri Anda untuk menarik partner belajar.'); ?></p>
                <a href="profile.php" class="btn btn-outline-primary btn-sm rounded-pill px-4">Edit Profil</a>
            </div>
        </div>

        <!-- Tampilan Pengguna / Teman di Sekitar -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5 class="fw-bold mb-0">Teman di Sekitar</h5>
            <a href="#" class="text-decoration-none small">Lihat Peta</a>
        </div>
        
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-0">
                <div class="p-3 border-bottom bg-light bg-opacity-50">
                    <p class="small text-muted mb-0"><i class="fa-solid fa-location-crosshairs text-primary me-1"></i> Menampilkan pengguna di sekitar Anda.</p>
                </div>
                <div class="p-3">
                    <?php if (empty($nearby_users)): ?>
                        <div class="text-center py-3">
                            <p class="text-muted small mb-0">Tidak ada pengguna lain di sekitar Anda saat ini.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach($nearby_users as $index => $nearby): ?>
                            <div class="d-flex align-items-center <?php echo $index < count($nearby_users) - 1 ? 'mb-3 pb-3 border-bottom' : ''; ?>">
                                <div class="bg-info text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 45px; height: 45px; font-size: 1.1rem;">
                                    <?php echo strtoupper(substr($nearby['name'], 0, 1)); ?>
                                </div>
                                <div class="flex-grow-1 min-w-0">
                                    <h6 class="fw-bold mb-0 text-truncate"><?php echo htmlspecialchars($nearby['name']); ?></h6>
                                    <small class="text-muted text-truncate d-block"><i class="fa-solid fa-map-pin me-1"></i> <?php echo htmlspecialchars($nearby['location'] ?? 'Lokasi tdk diketahui'); ?></small>
                                </div>
                                <div class="ms-2">
                                    <a href="requests.php?action=send&to=<?php echo $nearby['id']; ?>" class="btn btn-sm btn-primary rounded-circle shadow-sm" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;" title="Tambah Teman">
                                        <i class="fa-solid fa-user-plus"></i>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="card border-0 shadow-sm rounded-4 mb-4 overflow-hidden">
            <!-- Simulated Map -->
            <div class="bg-light position-relative" style="height: 200px; width: 100%;">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d126907.03964917408!2d106.75936886299411!3d-6.284050212001948!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3e945e34b9d%3A0x100c5e82dd4b820!2sJakarta%2C%20Daerah%20Khusus%20Ibukota%20Jakarta!5e0!3m2!1sid!2sid!4v1689230588884!5m2!1sid!2sid" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
