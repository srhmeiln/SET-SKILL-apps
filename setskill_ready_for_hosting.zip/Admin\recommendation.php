<?php
require_once 'header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_weights'])) {
    // In a real app, save to DB. Here we just show success message.
    $success = "Bobot rekomendasi berhasil diperbarui.";
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Manajemen Rekomendasi</h2>
</div>

<?php if (isset($success)): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Atur Kriteria Pencocokan</h5>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label">Bobot Skill Match (%)</label>
                        <input type="range" class="form-range" min="0" max="100" value="70">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Bobot Kedekatan Lokasi (%)</label>
                        <input type="range" class="form-range" min="0" max="100" value="20">
                    </div>
                    <div class="mb-4">
                        <label class="form-label">Bobot Rating User (%)</label>
                        <input type="range" class="form-range" min="0" max="100" value="10">
                    </div>
                    <button type="submit" name="update_weights" class="btn btn-primary">Simpan Pengaturan</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Featured Users (Prioritas)</h5>
                <p class="text-muted">Fitur untuk memprioritaskan pengguna tertentu dalam hasil rekomendasi.</p>
                <div class="alert alert-info">
                    Belum ada user yang ditandai sebagai featured.
                </div>
                <button class="btn btn-outline-primary btn-sm"><i class="fa-solid fa-plus me-1"></i> Tambah User</button>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
