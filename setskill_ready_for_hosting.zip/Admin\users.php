<?php
require_once 'header.php';

// Handle Block/Unblock & Verifikasi
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];
    
    if ($action == 'block') {
        $conn->query("UPDATE users SET status = 'blocked' WHERE id = $id AND role = 'user'");
    } elseif ($action == 'unblock') {
        $conn->query("UPDATE users SET status = 'active' WHERE id = $id AND role = 'user'");
    } elseif ($action == 'delete') {
        $conn->query("DELETE FROM users WHERE id = $id AND role = 'user'");
    } elseif ($action == 'approve_sub') {
        $conn->query("UPDATE users SET subscription_status = 'paid' WHERE id = $id AND role = 'user'");
    } elseif ($action == 'reject_sub') {
        // Hapus file bukti bayar jika ada (opsional)
        $conn->query("UPDATE users SET subscription_status = 'pending', payment_proof = NULL WHERE id = $id AND role = 'user'");
    }
    header("Location: users.php");
    exit();
}

$result = $conn->query("SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC");
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Manajemen Pengguna</h2>
</div>

<div class="card border-0 shadow-sm rounded-4">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Nama</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Status Akun</th>
                        <th>Status Langganan</th>
                        <th>Bukti Bayar</th>
                        <th class="pe-4 text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                            <?php echo strtoupper(substr($row['name'], 0, 1)); ?>
                                        </div>
                                        <div>
                                            <h6 class="mb-0 fw-bold"><?php echo htmlspecialchars($row['name']); ?></h6>
                                        </div>
                                    </div>
                                </td>
                                <td>@<?php echo htmlspecialchars($row['username']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['location'] ?? '-'); ?></td>
                                <td>
                                    <?php if ($row['status'] == 'active'): ?>
                                        <span class="badge bg-success rounded-pill">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger rounded-pill">Diblokir</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($row['subscription_status'] == 'paid'): ?>
                                        <span class="badge bg-primary rounded-pill">Lunas</span>
                                    <?php elseif ($row['subscription_status'] == 'waiting_verification'): ?>
                                        <span class="badge bg-warning text-dark rounded-pill">Menunggu Verifikasi</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary rounded-pill">Belum Bayar</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($row['payment_proof'])): ?>
                                        <a href="../assets/uploads/payments/<?php echo htmlspecialchars($row['payment_proof']); ?>" target="_blank" class="btn btn-sm btn-outline-info">Lihat Bukti</a>
                                    <?php else: ?>
                                        <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="pe-4 text-end">
                                    <?php if ($row['subscription_status'] == 'waiting_verification'): ?>
                                        <a href="users.php?action=approve_sub&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-success mb-1" onclick="return confirm('Setujui pembayaran user ini?');" title="Setujui"><i class="fa-solid fa-check"></i> Setujui</a>
                                        <a href="users.php?action=reject_sub&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-danger mb-1" onclick="return confirm('Tolak pembayaran user ini?');" title="Tolak"><i class="fa-solid fa-xmark"></i> Tolak</a>
                                        <br>
                                    <?php endif; ?>
                                    
                                    <?php if ($row['status'] == 'active'): ?>
                                        <a href="users.php?action=block&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-warning" onclick="return confirm('Blokir user ini?');" title="Blokir"><i class="fa-solid fa-ban"></i></a>
                                    <?php else: ?>
                                        <a href="users.php?action=unblock&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Buka blokir user ini?');" title="Buka Blokir"><i class="fa-solid fa-unlock"></i></a>
                                    <?php endif; ?>
                                    <a href="users.php?action=delete&id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus user ini permanen?');" title="Hapus"><i class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">Belum ada pengguna.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
